#!/bin/sh
cd /opt/zproxy
if [ -z "$3" ]; then
  /usr/bin/wine zmp.exe --host $1 --port $2 > /dev/null 2>&1
else
  /usr/bin/wine zmp.exe --host $1 --port $2 --playlist=$3 > /dev/null 2>&1
fi